-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Feb 06, 2017 at 04:35 PM
-- Server version: 10.1.13-MariaDB
-- PHP Version: 5.6.20

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `shop`
--

-- --------------------------------------------------------

--
-- Table structure for table `admintbl`
--

CREATE TABLE `admintbl` (
  `adminId` int(11) NOT NULL,
  `adminUsername` text NOT NULL,
  `adminPassword` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admintbl`
--

INSERT INTO `admintbl` (`adminId`, `adminUsername`, `adminPassword`) VALUES
(1, 'admin', 'password');

-- --------------------------------------------------------

--
-- Table structure for table `historytbl`
--

CREATE TABLE `historytbl` (
  `historyId` int(11) NOT NULL,
  `historyActivity` text NOT NULL,
  `historyTime` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `historytbl`
--

INSERT INTO `historytbl` (`historyId`, `historyActivity`, `historyTime`) VALUES
(1, 'admin logged into the System', '2017-02-04 22:12:16'),
(2, 'admin logged into the System', '2017-02-04 22:14:52'),
(3, 'admin logged into the System', '2017-02-04 22:26:22'),
(4, 'The name and price of exercise books was changed to exercise books and 2.53 respectively by admin', '2017-02-04 22:39:40'),
(5, 'The name and price of exercise books was changed to exercise books and 1.5 respectively by admin', '2017-02-04 22:40:50'),
(6, 'The name and price of exercise books was changed to exercise books and 1.5 respectively by admin', '2017-02-04 22:41:34'),
(7, 'The name and price of exercise books was changed to exercise books and 1.5 respectively by admin', '2017-02-04 22:44:03'),
(8, 'The name and price of exercise books was changed to exercise books and 1.5 respectively by admin', '2017-02-04 22:44:20'),
(9, 'The name and price of exercise books was changed to exercise books and 1.52 respectively by admin', '2017-02-04 22:44:27'),
(10, 'The name and price of exercise books was changed to exercise books and 1.52 respectively by admin', '2017-02-04 22:44:35'),
(11, 'The name and price of exercise books was changed to exercise books and 1.52 respectively by admin', '2017-02-04 22:44:44'),
(12, 'The name and price of exercise books was changed to exercise books and 1.52 respectively by admin', '2017-02-04 22:44:52'),
(13, 'The name and price of exercise was changed to exercise and 1.52 respectively by admin', '2017-02-04 22:58:26'),
(14, 'The name and price of exercise was changed to exercise and 1.520 respectively by admin', '2017-02-04 22:58:34'),
(15, 'The name and price of exercise was changed to exercise and 1.52 respectively by admin', '2017-02-04 22:58:39'),
(16, 'The name and price of exercise was changed to exercise and 1.52 respectively by admin', '2017-02-04 22:58:48'),
(17, 'The name and price of exercise was changed to exercise and 1.52 respectively by admin', '2017-02-04 22:59:30'),
(18, 'The name and price of exercise was changed to exercise and 1.5288 respectively by admin', '2017-02-04 22:59:37'),
(19, 'The name and price of exercise was changed to exercise and 1.5288 respectively by admin', '2017-02-04 23:03:36'),
(20, 'The name and price of exercise was changed to exercise and 1.52 respectively by admin', '2017-02-04 23:03:43'),
(21, 'admin logged into the System', '2017-02-05 08:42:08'),
(22, 'The name and price of  phones was edited to   ucc phones and 800 respectively by admin', '2017-02-05 10:34:52'),
(23, 'The name and price of   ucc phones was edited to    ucc phones and GH&cent; 810 respectively by admin', '2017-02-05 10:36:22'),
(24, 'The name and price of shirts was edited to  T - shirts and GHC 15 respectively by admin', '2017-02-05 10:38:43'),
(25, 'soap was deleted fromt the stock list by admin', '2017-02-05 10:47:25'),
(26, 'shoes was deleted fromt the stock list by admin', '2017-02-05 10:47:36'),
(27, '6 quantities of  T - shirts was added to the stock by admin', '2017-02-05 10:51:32'),
(28, 'The name and price of table was edited to  table and GHC 25 respectively by admin', '2017-02-05 10:54:27'),
(29, '15 quantities of  table was added to the stock by admin', '2017-02-05 10:54:43'),
(30, '12 quantities of    ucc phones was added to the stock by admin', '2017-02-05 10:59:23'),
(31, 'soap was deleted from the stock list by admin', '2017-02-05 11:01:12'),
(32, 'admin logged into the System', '2017-02-05 11:38:48'),
(33, 'admin logged into the System', '2017-02-05 12:42:24'),
(34, 'teller logged into the System', '2017-02-05 13:16:47'),
(35, 'teller logged into the System', '2017-02-05 13:17:33'),
(36, 'teller logged into the System', '2017-02-05 13:18:39'),
(37, 'teller logged into the System', '2017-02-05 15:49:45'),
(38, 'teller logged into the System', '2017-02-05 16:48:49'),
(39, ' T - shirts was deleted from the stock list by teller', '2017-02-05 17:43:39'),
(40, '   ucc phones was deleted from the stock list by teller', '2017-02-05 17:43:45'),
(41, 'The name and price of  table was edited to  table and GHC 25 respectively by teller', '2017-02-05 17:46:18'),
(42, 'The name and price of  table was edited to table and GHC 25 respectively by teller', '2017-02-05 17:47:37'),
(43, 'The name and price of table was edited to table and GHC 25 respectively by teller', '2017-02-05 17:47:48'),
(44, 'The name and price of table was edited to table and GHC 25 respectively by teller', '2017-02-05 17:47:57'),
(45, 'The name and price of table was edited to table and GHC 26 respectively by teller', '2017-02-05 17:48:07'),
(46, 'teller logged into the System', '2017-02-05 23:23:48'),
(47, '100 quantities of pen was added to the stock by teller', '2017-02-06 07:15:13'),
(48, '200 quantities of table was added to the stock by teller', '2017-02-06 07:15:23'),
(49, '300 quantities of brush was added to the stock by teller', '2017-02-06 07:16:12');

-- --------------------------------------------------------

--
-- Table structure for table `searchtbl`
--

CREATE TABLE `searchtbl` (
  `searchId` int(11) NOT NULL,
  `searchTerm` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `searchtbl`
--

INSERT INTO `searchtbl` (`searchId`, `searchTerm`) VALUES
(1, 'soap');

-- --------------------------------------------------------

--
-- Table structure for table `stocktbl`
--

CREATE TABLE `stocktbl` (
  `stockId` int(11) NOT NULL,
  `stockName` text NOT NULL,
  `stockPrice` double NOT NULL,
  `stockQuantity` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `stocktbl`
--

INSERT INTO `stocktbl` (`stockId`, `stockName`, `stockPrice`, `stockQuantity`) VALUES
(46, 'table', 26, 115),
(47, 'brush', 2, 292),
(48, 'bucket', 2, 14),
(49, 'pen', 22, 58),
(50, 'pencil', 21, 70),
(51, 'tooth brush', 2, 3);

-- --------------------------------------------------------

--
-- Table structure for table `tellertbl`
--

CREATE TABLE `tellertbl` (
  `tellerId` int(11) NOT NULL,
  `tellerName` text NOT NULL,
  `tellerPassword` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tellertbl`
--

INSERT INTO `tellertbl` (`tellerId`, `tellerName`, `tellerPassword`) VALUES
(1, 'teller', 'password');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admintbl`
--
ALTER TABLE `admintbl`
  ADD PRIMARY KEY (`adminId`);

--
-- Indexes for table `historytbl`
--
ALTER TABLE `historytbl`
  ADD PRIMARY KEY (`historyId`);

--
-- Indexes for table `searchtbl`
--
ALTER TABLE `searchtbl`
  ADD PRIMARY KEY (`searchId`);

--
-- Indexes for table `stocktbl`
--
ALTER TABLE `stocktbl`
  ADD PRIMARY KEY (`stockId`);

--
-- Indexes for table `tellertbl`
--
ALTER TABLE `tellertbl`
  ADD PRIMARY KEY (`tellerId`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admintbl`
--
ALTER TABLE `admintbl`
  MODIFY `adminId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `historytbl`
--
ALTER TABLE `historytbl`
  MODIFY `historyId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=50;
--
-- AUTO_INCREMENT for table `searchtbl`
--
ALTER TABLE `searchtbl`
  MODIFY `searchId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `stocktbl`
--
ALTER TABLE `stocktbl`
  MODIFY `stockId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=52;
--
-- AUTO_INCREMENT for table `tellertbl`
--
ALTER TABLE `tellertbl`
  MODIFY `tellerId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
